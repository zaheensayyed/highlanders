﻿/**
 * @license Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.html or http://ckeditor.com/license
 */

CKEDITOR.plugins.setLang( 'uicolor', 'nl', {
	title: 'UI Kleurenkiezer',
	preview: 'Live voorbeeld',
	config: 'Plak deze tekst in jouw config.js bestand',
	predefined: 'Voorgedefinieerde kleurensets'
});
